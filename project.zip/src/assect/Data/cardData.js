import card1 from "../Images/card-1.jpg";
import card2 from "../Images/card-2.jpg";
import card3 from "../Images/card-3.jpg";
import card4 from "../Images/card-4.jpg";

export const properties = [
  {
    id: 1,
    type: "HOUSE",
    price: "$290,000",
    address: "Rodeo Drive, 325",
    bedrooms: 3,
    bathrooms: 2,
    image: card1,
  },
  {
    id: 2,
    type: "HOUSE",
    price: "$290,000",
    address: "Rodeo Drive, 325",
    bedrooms: 3,
    bathrooms: 2,
    image: card2,
  },
  {
    id: 3,
    type: "HOUSE",
    price: "$290,000",
    address: "Rodeo Drive, 325",
    bedrooms: 3,
    bathrooms: 2,
    image: card4,
  },
  {
    id: 4,
    type: "HOUSE",
    price: "$290,000",
    address: "Rodeo Drive, 325",
    bedrooms: 3,
    bathrooms: 2,
    image: card3,
  },
  {
    id: 5,
    type: "HOUSE",
    price: "$290,000",
    address: "Rodeo Drive, 325",
    bedrooms: 3,
    bathrooms: 2,
    image: card1,
  },
  {
    id: 6,
    type: "HOUSE",
    price: "$290,000",
    address: "Rodeo Drive, 325",
    bedrooms: 3,
    bathrooms: 2,
    image: card3,
  },
];
