import carosals from "../../assect/Images/slider-1.jpg";
import carosal1 from "../../assect/Images/slider.jpg";

export const SliderData = [
  {
    id: 1,
    Header: "What Pepole say About Us",
    carosalImage: carosals,
    content:
      "We offer flexible appoinment scheaduliing and free to accommodate your busy life",
    titleName: "Dipak",
    job: "Detroit Michigan",
  },
  {
    id: 2,
    Header: "How can you helf you",
    carosalImage: carosal1,
    content:
      "Learn for past plane for future but leave in present becouse present is befor you.",
    titleName: "Kamlesh",
    job: "Devlopar web",
  },
  {
    id: 3,
    Header: "All DRs Details Us",
    carosalImage: carosals,
    content:
      "WE ALl of We offer flexible appoinment scheaduliing and free to accommodate your busy life",
    titleName: "Vikash",
    job: "Directer of Compny",
  },
];
