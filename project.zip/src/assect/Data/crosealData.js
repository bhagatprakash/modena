export const cardData = [
  {
    id: 1,

    content:
      "“Modena took us from the hand from the beginning to the end, totally recommendable will but again with them”",

    job: "Detroit Michigan",
  },
  {
    id: 2,

    content:
      "“We had such amazing experience while buying our new house using the services of Modena. We are very happy, thank you!”",

    job: "ALAN LOPEZ, SELLER",
  },
];
